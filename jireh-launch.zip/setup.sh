#!/bin/bash
echo 'Setting up Jireh environment...'
pip install -r requirements.txt
python3 jireh/main.py