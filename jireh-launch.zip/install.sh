#!/bin/bash
echo 'Running Jireh install...'
cd /opt/jireh && bash setup.sh